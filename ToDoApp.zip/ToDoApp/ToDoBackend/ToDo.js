const exp = require("constants");
const express  = require("express");
const fs=require("fs");
const app = express();
app.use(express.static(__dirname + "/public"))
app.use(express.urlencoded({extended:false}))
app.use(express.json());
app.get("/",(req,res)=>{
res.sendFile(__dirname + "/ToDoApp.html");
})
app.get("/ToDoData",(req,res)=>{
      let arr=fs.readFileSync(__dirname+"/ToDo.json","utf-8");
      arr=JSON.parse(arr);
      res.json(arr);
})
app.post("/UpdateToDoData",(req,res)=>{
      let arr=fs.readFileSync("ToDo.json","utf-8");
      arr=JSON.parse(arr);
      let obj = {};
      obj.task = req.body.task;
      obj.id=Date.now();
      arr.push(obj);
      fs.writeFileSync("ToDo.json",JSON.stringify(arr));
      res.redirect("/");
})
app.post("/deletetask",(req,res)=>{
      let arr=fs.readFileSync("ToDo.json","utf-8");
      arr=JSON.parse(arr);
      let  index = arr.findIndex((ele)=>{
            return ele.id == req.body.id;
      })
      arr.splice(index,1);
      fs.writeFileSync("ToDo.json",JSON.stringify(arr));
      res.send();
})

app.listen(3000,(err)=>{
      if(err)console.log(err);
      console.log("Server Started");
})