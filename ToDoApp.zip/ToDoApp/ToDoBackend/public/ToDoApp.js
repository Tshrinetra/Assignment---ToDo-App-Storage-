fetch("/ToDoData")
	.then((data) => {
		return data.json();
	})
	.then((data) => {
		data.forEach((ele) => {
			let div = document.createElement("div");
			div.id = "task";
			let h1 = document.createElement("h1");
			let input = document.createElement("input");
			let button = document.createElement("button");
			let div1 = document.createElement("div");
			input.type = "checkbox";
			h1.innerHTML = ele.task;
			button.innerText = "X";
			div1.append(input, button);

			button.addEventListener("click", () => {
				if (input.checked) deletefunction(ele.id);
			});
			div.append(h1, div1);
			document
				.querySelector("body .container .tasklist .taskstart")
				.append(div);
		});
		let div = document.createElement("div");
	});
function clickfunction() {
	fetch("/UpdateToDoData")
		.then((data) => {
			return data.json();
		})
		.then((data) => {
			data.forEach((ele) => {
				let div = document.createElement("div");
				div.id = "task";
				let h1 = document.createElement("h1");
				let input = document.createElement("input");
				let button = document.createElement("button");
				input.type = "checkbox";
				h1.innerHTML = ele.task;
				button.innerText = "X";
				div.append(h1, input, button);
				document
					.querySelector("body .container .tasklist .taskstart")
					.append(div);
			});

			window.location.reload();
		});
}
function deletefunction(id) {
	fetch("/deletetask", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({
			id: id,
		}),
	})
		.then((data) => {
			return data.text();
		})
		.then((data) => {
			window.location.reload();
		});
}
